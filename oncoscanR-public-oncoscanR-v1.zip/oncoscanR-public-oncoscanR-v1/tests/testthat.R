library(testthat)
library(oncoscanR)

test_check("oncoscanR")
